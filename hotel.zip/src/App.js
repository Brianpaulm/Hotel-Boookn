import './App.css';
import Home from './Home'
import Header from './Header'

function App() {
  return (
    //BEM
    <div className="app">
    
    <Header/>
    <Home />
     {/*Home*/}
       {/*Header*/}

       {/*Banner*/}

         {/*Search*/}


       {/*Hotel Cards*/}

       {/*Footer*/}

{/*Search*/}




      
    </div>
  );
}

export default App;
